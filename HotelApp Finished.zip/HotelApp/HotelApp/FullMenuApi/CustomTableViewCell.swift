//
//  CustomTableViewCell.swift
//  HotelApp
//
//  Created by Calsoft on 02/05/23.
//

import UIKit

class CustomTableViewCell: UITableViewCell {
    static let identifier = "CustomTableViewCell"
        
        override class func awakeFromNib() {
            super.awakeFromNib()
        }
        
        override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
            super.init(style: style, reuseIdentifier: reuseIdentifier)
        }
        
        required init?(coder: NSCoder) {
            fatalError("init(coder:) has not been implemented")
        }


}
