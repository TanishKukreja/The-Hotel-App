//
//  AnimationViewController.swift
//  HotelApp
//
//  Created by Calsoft on 02/05/23.
//

import UIKit

class AnimationViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        
    }
    
}
