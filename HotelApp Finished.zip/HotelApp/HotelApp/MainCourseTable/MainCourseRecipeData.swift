//
//  MainCourseRecipeData.swift
//  HotelApp
//
//  Created by Calsoft on 02/05/23.
//

import Foundation

class MainCourseRecipeData{
    
    var MainCourseRecipeName: String
    var MainCourseRecipePrice: Int
    var mainCourseImage: String
    var recipeQuantity: Int
    var recipeSelected: Bool
    
    init(mainRecName: String, mainRecPrice: Int, mainRecImage: String,mainRecQuantity:Int, mainRecSelected:Bool) {
        MainCourseRecipeName = mainRecName
        MainCourseRecipePrice = mainRecPrice
        mainCourseImage = mainRecImage
        recipeQuantity = mainRecQuantity
        recipeSelected = mainRecSelected
    }
}
