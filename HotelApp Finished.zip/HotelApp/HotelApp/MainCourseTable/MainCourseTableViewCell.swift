//
//  MainCourseTableViewCell.swift
//  HotelApp
//
//  Created by Calsoft on 02/05/23.
//

import UIKit

class MainCourseTableViewCell: UITableViewCell {
    
    var count = 0
    var delegate: ChangeItemQuantity?
    
    @IBOutlet weak var myMainCourseImage: UIImageView!
    @IBOutlet weak var MainCourseRecipePrice: UILabel!
    @IBOutlet weak var MainCourseRecipeName: UILabel!
    @IBOutlet weak var mainCourseImage: UIImageView!
  
    
    @IBAction func addMainItemTapped(_ sender: Any) {
        count += 1
        MainItemCount.text = "\(count)"
        delegate?.changeItemQuantityAfterChackingItemName(name: MainCourseRecipeName.text ?? "", quantity: count)
    }
    @IBOutlet weak var MainItemCount: UILabel!
    
    @IBOutlet weak var removeMainItem: UIButton!
    
    @IBAction func removeMainItemTapped(_ sender: Any) {
        if(count > 0){
            count -= 1
            MainItemCount.text = "\(count)"
            delegate?.changeItemQuantityAfterChackingItemName(name: MainCourseRecipeName.text ?? "", quantity: count)
        }
        else{
            print("item cant be less then zero")
        }
    }
    
    @IBOutlet weak var addMainItem: UIButton!
  
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

       
    }

}
