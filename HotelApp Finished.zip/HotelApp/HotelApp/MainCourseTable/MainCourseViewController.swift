//
//  MainCourseViewController.swift
//  HotelApp
//
//  Created by Calsoft on 02/05/23.
//

import UIKit

//let favMainCourseName = ["DalMakhni","Paneer","Chole","Mix-Veg","Chicken","Chapaati","Naan"]
//var favRecipe = [MainCourseRecipeData]()
var listMainCourseRecipe = [recipeData]()

class MainCourseViewController: UIViewController, ChangeItemQuantity {

    @IBOutlet weak var itemCount: UILabel!
    
    func changeItemQuantityAfterChackingItemName(name: String, quantity: Int) {
        for i in 0..<listMainCourseRecipe.count{
            if listMainCourseRecipe[i].recipeName == name{
                listMainCourseRecipe[i].recipeQuantity = quantity
            }
        }
        dump(listMainCourseRecipe)
    }
    
    
    @IBOutlet weak var myTable2: UITableView!
    
//    var favoriteMainCourse = [Int:Bool]()
//    private func blankfavoriteMainCourse(){
//        for i in 0...favoriteMainCourse.count{
//            favoriteMainCourse[i] = false
//        }
//    }

    
    @IBAction func MainCart(_ sender: Any) {
        
        let AddedCartRecipeHome = self.storyboard?.instantiateViewController(withIdentifier: "favoritehome") as! CartViewController
        let mainCourseFavRecipe = listMainCourseRecipe.filter{ $0.recipeSelected == true }
        favRecipe.append(contentsOf: mainCourseFavRecipe)
        AddedCartRecipeHome.favoriteList = favRecipe
        self.navigationController?.pushViewController(AddedCartRecipeHome, animated: true)
    }
    
    private func blankFavoriteRecipe(){
        for i in 0...favRecipe.count{
            favRecipe[i].recipeSelected=false
        }
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        

        let recipe7 = recipeData(recName: "DalMakhni", recPrice: 320, recPhoto: "dal-makhani",recQuantity : 0, recSelected: false)
        listMainCourseRecipe.append(recipe7)
        
        let recipe8 = recipeData(recName: "Paneer", recPrice: 360, recPhoto: "Shahi-paneer",recQuantity : 0, recSelected: false )
        listMainCourseRecipe.append(recipe8)
        
        let recipe9 = recipeData(recName: "Chole", recPrice: 330, recPhoto: "chole",recQuantity : 0, recSelected: false)
        listMainCourseRecipe.append(recipe9)
        
        let recipe10 = recipeData(recName: "Mix-Veg", recPrice: 300, recPhoto: "mixveg",recQuantity : 0, recSelected: false)
        listMainCourseRecipe.append(recipe10)
        
        let recipe12 = recipeData(recName: "Chicken", recPrice: 330, recPhoto: "butter-chicken",recQuantity : 0, recSelected: false)
        listMainCourseRecipe.append(recipe12)
        
        let recipe13 = recipeData(recName: "Chapaati", recPrice: 30, recPhoto: "Chapaati",recQuantity : 0, recSelected: false)
        listMainCourseRecipe.append(recipe13)
        
        let recipe14 = recipeData(recName: "Naan", recPrice: 80, recPhoto: "Naan",recQuantity : 0, recSelected: false)
        listMainCourseRecipe.append(recipe14)
        
    }
}
extension MainCourseViewController : UITableViewDelegate,UITableViewDataSource{
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return listMainCourseRecipe.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = myTable2.dequeueReusableCell(withIdentifier: "maincell", for: indexPath) as! MainCourseTableViewCell
        if listMainCourseRecipe[indexPath.row].recipeSelected == true{
            cell.myMainCourseImage.image = UIImage(named:"selectedheart")
            cell.MainCourseRecipeName.text = listMainCourseRecipe[indexPath.row].recipeName
           
        }
        else{
            cell.myMainCourseImage.image = UIImage(named: "unselectedheart")
            cell.MainCourseRecipeName.text = listMainCourseRecipe[indexPath.row].recipeName
           
        }
        
        cell.delegate = self
        cell.selectionStyle = .none
        cell.MainItemCount.text = "\(listMainCourseRecipe[indexPath.row].recipeQuantity)"
        cell.MainCourseRecipePrice.text = "\(listMainCourseRecipe[indexPath.row].recipePrice)"
        cell.mainCourseImage.image = UIImage(named: listMainCourseRecipe[indexPath.row].recipeImage)
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
    

        let cell = myTable2.cellForRow(at: indexPath) as! MainCourseTableViewCell
        cell.myMainCourseImage.image = UIImage(named: "selectedheart")
        listMainCourseRecipe[indexPath.row].recipeSelected = true
    }
 
    func tableView(_ tableView: UITableView, didDeselectRowAt indexPath: IndexPath) {
        let cell = myTable2.cellForRow(at: indexPath) as! MainCourseTableViewCell
        cell.myMainCourseImage.image = UIImage(named:"unselectedheart")
        listMainCourseRecipe[indexPath.row].recipeSelected = false
    }
}
