//
//  DessertsViewController.swift
//  HotelApp
//
//  Created by Calsoft on 02/05/23.
//

import UIKit

//let favDessertName = ["Rabri","Gulab_jamun","Kaju Katli","Jalebi","RasMalai"]
//var favRecipe = [DessertRecipeData]()
var listDessertRecipe = [recipeData]()

class DessertsViewController: UIViewController,ChangeItemQuantity{
    
    @IBOutlet weak var myTable3: UITableView!
    
    
    
    func changeItemQuantityAfterChackingItemName(name: String, quantity: Int) {
        for i in 0..<listDessertRecipe.count{
            if listDessertRecipe[i].recipeName == name{
                listDessertRecipe[i].recipeQuantity = quantity
            }
        }
        dump(listDessertRecipe)
    }
    private func blankFavoriteRecipe(){
        for i in 0...favRecipe.count{
            favRecipe[i].recipeSelected=false
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        let recipe15 = recipeData(recName: "Rabri", recPrice: 70, recPhoto: "Rabri",recQuantity: 0,recSelected: false)
        listDessertRecipe.append(recipe15)
        
        let recipe16 = recipeData(recName: "Gulab_jamun", recPrice: 60, recPhoto: "Gulab_jamun",recQuantity: 0,recSelected: false)
        listDessertRecipe.append(recipe16)
        
        let recipe17 = recipeData(recName: "Kaju Katli", recPrice: 70, recPhoto: "Kaju_katli",recQuantity: 0,recSelected: false)
        listDessertRecipe.append(recipe17)
        
        let recipe18 = recipeData(recName: "Jalebi", recPrice: 60, recPhoto: "jalebi",recQuantity: 0,recSelected: false)
        listDessertRecipe.append(recipe18)
        
        let recipe19 = recipeData(recName: "RasMalai", recPrice: 80, recPhoto: "rasmalai",recQuantity: 0,recSelected: false)
        listDessertRecipe.append(recipe19)
        
      
    }
    
    @IBAction func addToCartButton(_ sender: Any) {
        
            let AddedCartRecipeHome = self.storyboard?.instantiateViewController(withIdentifier: "favoritehome") as! CartViewController
        let DessertfavRecipe = listDessertRecipe.filter{ $0.recipeSelected == true }
        favRecipe.append(contentsOf: DessertfavRecipe)
            AddedCartRecipeHome.favoriteList = favRecipe
            self.navigationController?.pushViewController(AddedCartRecipeHome, animated: true)
            
        
    }
}
extension DessertsViewController : UITableViewDelegate,UITableViewDataSource{
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return listDessertRecipe.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = myTable3.dequeueReusableCell(withIdentifier: "cell3", for: indexPath) as! DessertsTableViewCell
        if listDessertRecipe[indexPath.row].recipeSelected == true{
            cell.myDessertImage.image = UIImage(named: "selectedheart")
            cell.DessertName.text = listDessertRecipe[indexPath.row].recipeName
            cell.DessertPrice.text = "\(listDessertRecipe[indexPath.row].recipePrice)"
        }
        else{
            cell.myDessertImage.image = UIImage(named: "unselectedheart")
            cell.DessertName.text = listDessertRecipe[indexPath.row].recipeName
            cell.DessertPrice.text = "\(listDessertRecipe[indexPath.row].recipePrice)"
        }
        cell.delegate = self
        cell.selectionStyle = .none
        cell.DessertsItemCount.text = "\(listDessertRecipe[indexPath.row].recipeQuantity)"
        cell.DessertPrice.text = "\(listDessertRecipe[indexPath.row].recipePrice)"
        cell.DessertImage.image = UIImage(named: listDessertRecipe[indexPath.row].recipeImage)
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
    
        
        let cell = myTable3.cellForRow(at: indexPath) as! DessertsTableViewCell
        cell.myDessertImage.image = UIImage(named: "selectedheart")
        listDessertRecipe[indexPath.row].recipeSelected = true
    }
 
    func tableView(_ tableView: UITableView, didDeselectRowAt indexPath: IndexPath) {
        let cell = myTable3.cellForRow(at: indexPath) as! DessertsTableViewCell
        cell.myDessertImage.image = UIImage(named:"unselectedheart")
        listDessertRecipe[indexPath.row].recipeSelected = false
    }
}
