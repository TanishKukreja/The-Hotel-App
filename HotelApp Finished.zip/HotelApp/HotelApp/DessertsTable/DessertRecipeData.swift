//
//  DessertRecipeData.swift
//  HotelApp
//
//  Created by Calsoft on 02/05/23.
//

import Foundation

class DessertRecipeData{
     
    var DessertName : String
    var DessertPrice : Int
    var DessertImage : String
    var DessertQuantity : Int
    var DessertSelected : Bool
    init(DsrtName: String , DsrtPrice: Int, DsrtImage:String , DsrtQuantity:Int,DsrtSelected:Bool){
        DessertName = DsrtName
        DessertPrice = DsrtPrice
        DessertImage = DsrtImage
        DessertQuantity = DsrtQuantity
        DessertSelected = DsrtSelected
    }
}
