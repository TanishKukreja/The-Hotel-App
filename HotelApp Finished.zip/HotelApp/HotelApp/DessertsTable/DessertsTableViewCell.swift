//
//  DessertsTableViewCell.swift
//  HotelApp
//
//  Created by Calsoft on 02/05/23.
//

import UIKit

class DessertsTableViewCell: UITableViewCell {
    
   
    var count = 0
    var delegate: ChangeItemQuantity?

    @IBOutlet weak var myDessertImage: UIImageView!
    @IBOutlet weak var DessertPrice: UILabel!
    @IBOutlet weak var DessertName: UILabel!
    @IBOutlet weak var DessertImage: UIImageView!
    
    @IBOutlet weak var addDessertsItem: UIButton!
    @IBAction func addDessertsItemTapped(_ sender: Any) {
        count += 1
        DessertsItemCount.text = "\(count)"
        delegate?.changeItemQuantityAfterChackingItemName(name: DessertName.text ?? "", quantity: count)
    }
    
    @IBOutlet weak var DessertsItemCount: UILabel!
    
    @IBOutlet weak var removeDessertsItem: UIButton!
    @IBAction func removeSDessertsItemTapped(_ sender: Any) {
        if(count > 0){
            count -= 1
            DessertsItemCount.text = "\(count)"
            delegate?.changeItemQuantityAfterChackingItemName(name: DessertName.text ?? "", quantity: count)
        }
        else{
            print("item cant be less then zero")
        }
        
    }
    
        
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
