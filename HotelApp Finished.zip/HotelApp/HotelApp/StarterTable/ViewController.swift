//
//  ViewController.swift
//  HotelApp
//
//  Created by Calsoft on 18/04/23.
//

import UIKit
import Firebase
//import Lottie

//let favRecipeName = ["Pizza","Noodles","Burger","Chaap","Pav bhaji","Kachori","Tikki","Dahi Balle","Samosa"]
var favRecipe = [recipeData]()
var listRecipe = [recipeData]()

class ViewController: UIViewController,ChangeItemQuantity{
    
    func changeItemQuantityAfterChackingItemName(name: String, quantity: Int) {
        for i in 0..<listRecipe.count{
            if listRecipe[i].recipeName == name{
                listRecipe[i].recipeQuantity = quantity
            }
        }
        dump(listRecipe)
    }
    
    
    
    @IBAction func AddtoCartButton(_ sender: Any) {
        let AddedCartRecipeHome = self.storyboard?.instantiateViewController(withIdentifier: "favoritehome") as! CartViewController
        let StarterFavRecipe = listRecipe.filter{ $0.recipeSelected == true }
        favRecipe.append(contentsOf: StarterFavRecipe)
        AddedCartRecipeHome.favoriteList = favRecipe
        self.navigationController?.pushViewController(AddedCartRecipeHome, animated: true)
        
    }
    @IBOutlet weak var addStarterItem: UIButton!
    @IBOutlet weak var DessertButton: UIButton!
    @IBOutlet weak var MainCourseButton: UIButton!
    @IBOutlet weak var startersButton: UIButton!
    
    @IBAction func starter(_ sender: Any) {
        performSegue(withIdentifier: "toTable", sender: self)
    }
    
    let trackLayer = CAShapeLayer()
    let shapeLayer = CAShapeLayer()
    
    
    
    @IBAction func mainCourseButton(_ sender: Any) {
        performSegue(withIdentifier: "toMainCourseTable", sender: self)
    }
    
    @IBOutlet weak var myTable: UITableView!
    
    
    
    
    private func blankFavoriteRecipe(){
        for i in 0...favRecipe.count{
            favRecipe[i].recipeSelected=false
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let recipe1 = recipeData(recName: "Pizza", recPrice: 180, recPhoto: "pizza", recQuantity: 0, recSelected: false)
        listRecipe.append(recipe1)
        
        let recipe2 = recipeData(recName: "Noodles", recPrice: 120, recPhoto: "noodles", recQuantity: 0, recSelected: false)
        listRecipe.append(recipe2)
        
        let recipe3 = recipeData(recName: "Burger", recPrice: 100, recPhoto: "burger", recQuantity: 0, recSelected: false)
        listRecipe.append(recipe3)
        
        let recipe4 = recipeData(recName: "Chaap", recPrice: 200, recPhoto: "butter-chicken", recQuantity: 0, recSelected: false)
        listRecipe.append(recipe4)
        
        let recipe5 = recipeData(recName: "Pav Bhaji", recPrice: 160, recPhoto: "pavBhaji", recQuantity: 0, recSelected: false)
        listRecipe.append(recipe5)
        
        let recipe7 = recipeData(recName: "Raj kachori", recPrice: 160, recPhoto: "RajKachori", recQuantity: 0, recSelected: false)
        listRecipe.append(recipe7)
        
        let recipe8 = recipeData(recName: "Tikki", recPrice: 120, recPhoto: "tikki", recQuantity: 0, recSelected: false)
        listRecipe.append(recipe8)
        
        let recipe9 = recipeData(recName: "Dahi balla", recPrice: 90, recPhoto: "dahiballe", recQuantity: 0, recSelected: false)
        listRecipe.append(recipe9)
        
        let recipe10 = recipeData(recName: "Samosa", recPrice: 30, recPhoto: "samosa", recQuantity: 0, recSelected: false)
        listRecipe.append(recipe10)
    }
}

extension ViewController : UITableViewDelegate,UITableViewDataSource{
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return listRecipe.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = myTable.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! MyTableViewCell2TableViewCell
        if listRecipe[indexPath.row].recipeSelected == true{
            cell.myImage.image = UIImage(named: "selectedheart")
            cell.recipeName.text = listRecipe[indexPath.row].recipeName
        }
        else{
            cell.myImage.image = UIImage(named: "unselectedheart")
            cell.recipeName.text = listRecipe[indexPath.row].recipeName
        }
        
        cell.delegate = self
        cell.itemCount.text = "\(listRecipe[indexPath.row].recipeQuantity)"
        cell.recipePrice.text = "\(listRecipe[indexPath.row].recipePrice)"
        cell.recipeImage.image = UIImage(named: listRecipe[indexPath.row].recipeImage)
        cell.selectionStyle = .none
        return cell
    }
  
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {

        
        let cell = myTable.cellForRow(at: indexPath) as! MyTableViewCell2TableViewCell
        cell.myImage.image = UIImage(named: "selectedheart")
        listRecipe[indexPath.row].recipeSelected = true
    }
    
    func tableView(_ tableView: UITableView, didDeselectRowAt indexPath: IndexPath) {
        let cell = myTable.cellForRow(at: indexPath) as! MyTableViewCell2TableViewCell
        cell.myImage.image = UIImage(named:"unselectedheart")
        listRecipe[indexPath.row].recipeSelected = false
    }
}

