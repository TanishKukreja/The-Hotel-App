//
//  recipeData.swift
//  HotelApp
//
//  Created by Calsoft on 21/04/23.
//

import Foundation


class recipeData{
    
    var recipeName: String
    var recipePrice: Int
    var recipeImage: String
    var recipeQuantity: Int
    var recipeSelected: Bool
    init(recName: String, recPrice: Int, recPhoto: String, recQuantity: Int, recSelected: Bool){
        recipeName = recName
        recipePrice = recPrice
        recipeImage = recPhoto
        recipeQuantity = recQuantity
        recipeSelected = recSelected
    }

}
