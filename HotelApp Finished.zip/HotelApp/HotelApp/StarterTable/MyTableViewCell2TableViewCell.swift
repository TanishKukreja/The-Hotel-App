//
//  MyTableViewCell2TableViewCell.swift
//  HotelApp
//
//  Created by Calsoft on 24/04/23.
//

import UIKit
protocol ChangeItemQuantity{
    func changeItemQuantityAfterChackingItemName(name: String, quantity: Int)
}

class MyTableViewCell2TableViewCell: UITableViewCell {
    
    var count = 0
    var delegate: ChangeItemQuantity?
    
    @IBOutlet weak var myImage: UIImageView!
    @IBOutlet weak var recipePrice: UILabel!
    @IBOutlet weak var recipeName: UILabel!
    @IBOutlet weak var recipeImage: UIImageView!
    // var finalQuantity = 0
    
    @IBAction func addStarterItemTapped(_ sender: Any) {
        count += 1
        itemCount.text = "\(count)"
        delegate?.changeItemQuantityAfterChackingItemName(name: recipeName.text ?? "", quantity: count)
    }
    @IBOutlet weak var itemCount: UILabel!
    
    @IBOutlet weak var removeStarterItem: UIButton!
    
    @IBAction func removeStarterItemTapped(_ sender: Any) {
        if(count > 0){
            count -= 1
            itemCount.text = "\(count)"
            delegate?.changeItemQuantityAfterChackingItemName(name: recipeName.text ?? "", quantity: count)
            
        }
        else{
            print("item cant be less then zero")
        }
        
        
    }
    
    @IBOutlet weak var addStarterItem: UIButton!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }
    
}
