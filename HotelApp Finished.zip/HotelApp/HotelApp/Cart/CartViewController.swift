//
//  CartViewController.swift
//  HotelApp
//
//  Created by Calsoft on 04/05/23.
//

import UIKit

class CartViewController: UIViewController {
    
    var favoriteList = [recipeData]()
    var tempList = [Int]()
    
    let trackLayer = CAShapeLayer()
    let shapeLayer = CAShapeLayer()
    
    func okButton(){
           trackLayer.isHidden = true
           shapeLayer.isHidden = true
           self.performSegue(withIdentifier: "bill", sender: self)
       }
    @IBAction func placeOrder(_ sender: Any) {
        Animations()
}

@objc private func handleTap() {
    handleTapFunctions()
}
    @IBOutlet weak var cartTable: UITableView!
    
    @IBOutlet weak var lbl: UILabel!
    var recipeName = ""
    
    var subTotal = Int()
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        for i in 0..<favoriteList.count{
            if favoriteList[i].recipeSelected==true{
                tempList.append(i)
            }
        }
//        for j in 0..<favoriteList.count{
//            if favoriteList[j].recipeSelected == true{
//                tempList2.append(j)
//            }
//        }
    }

    func Animations(){
        //    startersButton.isEnabled=false
        //    MainCourseButton.isEnabled=false
        //    DessertButton.isEnabled=false

            let allertTitle = "Status"
            let message = "Click on circle to confirm your order!"
            let alertBox = UIAlertController(title: allertTitle, message: message, preferredStyle: .alert)
            
            let alertAction = UIAlertAction(title: "ok", style: .default , handler: nil)
            alertBox.addAction(alertAction)

            self.present(alertBox,animated: true,completion: nil)
            
            let center = view.center
            let circularPath = UIBezierPath(arcCenter: center, radius: 200, startAngle: -CGFloat.pi / 2, endAngle: 2 * CGFloat.pi, clockwise: true)
            trackLayer.path = circularPath.cgPath
            trackLayer.strokeColor = UIColor.lightGray.cgColor
            trackLayer.lineWidth = 30
            trackLayer.fillColor = UIColor.clear.cgColor
            trackLayer.lineCap = CAShapeLayerLineCap.round
            trackLayer.isOpaque = true
            trackLayer.removeFromSuperlayer()
            view.layer.addSublayer(trackLayer)
            trackLayer.backgroundColor=UIColor.white.cgColor
            shapeLayer.path = circularPath.cgPath
            shapeLayer.strokeColor = UIColor.green.cgColor
            shapeLayer.lineWidth = 10
            shapeLayer.fillColor = UIColor.clear.cgColor
            shapeLayer.lineCap = CAShapeLayerLineCap.round
            shapeLayer.strokeEnd = 0
            shapeLayer.isHidden = false
            
            view.layer.addSublayer(shapeLayer)
            view.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(handleTap)))

    }
    func handleTapFunctions(){
        print("Attempting to animate stroke")
        
        let basicAnimation = CABasicAnimation(keyPath: "strokeEnd")
        
        basicAnimation.toValue = 1
        
        basicAnimation.duration = 1
        
        basicAnimation.fillMode = CAMediaTimingFillMode.forwards
        basicAnimation.isRemovedOnCompletion = false
        
        shapeLayer.add(basicAnimation, forKey: "urSoBasic")
        
        let allertTitle = "Status"
        let message = "Order has been placed"
        let alertBox = UIAlertController(title: allertTitle, message: message, preferredStyle: .alert)
        let alertAction = UIAlertAction(title: "ok", style: .default) { action in
            self.okButton()
            
        }
        alertBox.addAction(alertAction)
        self.present(alertBox,animated: true,completion: nil)
    }
    }
extension CartViewController:UITableViewDelegate,UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return tempList.count+1;
      //  return tempList2.count;
    
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = cartTable.dequeueReusableCell(withIdentifier: "cell2", for: indexPath)
     // cell.textLabel?.text = favRecipeName[tempList[indexPath.row]]
      
        if(indexPath.row < tempList.count){
            cell.textLabel?.text = "\(favoriteList[indexPath.row].recipeName)   \(favoriteList[indexPath.row].recipePrice)  X : \(favoriteList[indexPath.row].recipeQuantity)  =   \(favoriteList[indexPath.row].recipePrice * favoriteList[indexPath.row].recipeQuantity) "
            subTotal += favoriteList[indexPath.row].recipePrice * favoriteList[indexPath.row].recipeQuantity
        }else if(indexPath.row == tempList.count){
            cell.textLabel?.text = "Rs : \(subTotal)"
        }
    
        return cell
    }
    
    
}
