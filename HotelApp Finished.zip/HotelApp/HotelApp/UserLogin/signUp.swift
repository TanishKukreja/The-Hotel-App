//
//  signUp.swift
//  HotelApp
//
//  Created by Calsoft on 21/04/23.
//

import Foundation
import UIKit
import Firebase

class signUp : UIViewController{
    
    @IBOutlet weak var signUpEmail: UITextField!
    
    @IBOutlet weak var signUpPassword: UITextField!
    
    var isPasswordValid : Bool{
        let passwordTest = NSPredicate(format: "SELF MATCHES %@","^(?=.*\\d)(?=.*[a-z])(?=.*[A-Z])[0-9a-zA-Z!@#$%^&*()\\-_=+{}|?>.<,:;~`’]{8,}$")
        return passwordTest.evaluate(with: self)
    }
    
    @IBAction func signUp(_ sender: Any) {
        
        guard let signUpEmail = signUpEmail.text else {return}
        guard var signUpPassword = signUpPassword.text else {return}
        
        //   passwdValidation
        
//        if(!signUpPassword.isPasswordValid()){
//           // print("wrong")
//
//
//            let allertTitle = "Status"
//            let message = "Condtion not satisfied"
//            let alertBox = UIAlertController(title: allertTitle, message: message, preferredStyle: .alert)
//
//            let alertAction = UIAlertAction(title: "ok", style: .default) { UIAlertAction in
//                return
//            }
//            alertBox.addAction(alertAction)
//
//            self.present(alertBox,animated: true,completion: nil)
//            return
//
//    }
    
        Auth.auth().createUser(withEmail: signUpEmail, password: signUpPassword)
        { firebaseResult, error in
            
            if let e = error {
                
                let allertTitle = "Status"
                let message = "At Lease 8 Charcaters or you are using old password"
                let alertBox = UIAlertController(title: allertTitle, message: message, preferredStyle: .alert)
                
                let alertAction = UIAlertAction(title: "ok", style: .default , handler: nil)
                alertBox.addAction(alertAction)
                
                self.present(alertBox,animated: true,completion: nil)

            }
            else{
                let allertTitle = "Status"
                let message = "Account Created! "
                let alertBox = UIAlertController(title: allertTitle, message: message, preferredStyle: .alert)
                let alertAction = UIAlertAction(title: "ok", style: .default) { action in
                    self.dismiss(animated: true)
                }
                alertBox.addAction(alertAction)
                self.present(alertBox,animated: true,completion: nil)
                
                
            }
        }
    
    }
}
