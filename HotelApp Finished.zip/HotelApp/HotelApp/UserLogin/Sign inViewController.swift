//
//  Sign inViewController.swift
//  HotelApp
//
//  Created by Calsoft on 18/04/23.
//

import UIKit
import Firebase


class Sign_inViewController: UIViewController {
    
    
    @IBOutlet weak var Email: UITextField!
    
    @IBOutlet weak var Password: UITextField!
    @IBOutlet weak var ForgerPassword: UIButton!
    @IBOutlet weak var signIn: UIButton!
   
    @IBAction func signIn(_ sender: Any) {
        
        guard let signUpEmail = Email.text else {return}
        guard let signUpPassword = Password.text
        else {return}

            Auth.auth().signIn(withEmail: signUpEmail, password: signUpPassword) { firebaseResult, error in
                if let e = error{
                   // print("Error in signIn")
                    let allertTitle = "Status"
                    let message = "Wrong Credentials"
                    let alertBox = UIAlertController(title: allertTitle, message: message, preferredStyle: .alert)
                    
                    let alertAction = UIAlertAction(title: "ok", style: .default , handler: nil)
                    alertBox.addAction(alertAction)

                    self.present(alertBox,animated: true,completion: nil)
                    
                }
                else{
                    self.performSegue(withIdentifier:"TheTaj" , sender: self)
                    //self.present(Menu2ViewController(), animated: true){
                        
                    }
                }
    }

    }
    

