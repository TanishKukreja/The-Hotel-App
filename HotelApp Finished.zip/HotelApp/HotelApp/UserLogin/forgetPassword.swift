//
//  forgetPassword.swift
//  HotelApp
//
//  Created by Calsoft on 21/04/23.
//

import Foundation
import Firebase
import UIKit


class forgerPassword : UIViewController{
    
    @IBOutlet weak var forgetEmail: UITextField!
    @IBAction func forgetPassword(_ sender: Any) {
        
        Auth.auth().sendPasswordReset(withEmail: forgetEmail.text!){(error) in
            if error == nil{
                print("Link Sent")
                let allertTitle = "Status"
                let message = "Reset Link has been sent successfully"
                let alertBox = UIAlertController(title: allertTitle, message: message, preferredStyle: .alert)
                
                let alertAction = UIAlertAction(title: "ok", style: .default , handler: nil)
                alertBox.addAction(alertAction)
                
                self.present(alertBox,animated: true,completion: nil)

            }
           
            else  {
                let allertTitle = "Status"
                let message = "Enter recovery mail to verify otp"
                let alertBox = UIAlertController(title: allertTitle, message: message, preferredStyle: .alert)
                
                let alertAction = UIAlertAction(title: "ok", style: .default , handler: nil)
                alertBox.addAction(alertAction)
                
                self.present(alertBox,animated: true,completion: nil)
            }
        }
    }
}
